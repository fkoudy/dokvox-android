# Dokvox → Google Play: návod krok za krokem

Tato složka udělá z webové aplikace Dokvox Android aplikaci pro Google Play (pomocí Capacitoru). Navíc přidá to, co web neumí:

- **reklamy** AdMob s okénkem souhlasu podle GDPR,
- **předplatné PRO** přes Google Play (spravuje ho RevenueCat),
- **denní připomínky** (oznámení v telefonu),
- **mluvené kartičky**: rozpoznávání řeči přímo v telefonu (prohlížeč uvnitř Android aplikace to sám neumí, proto je přidaný doplněk pro řeč a oprávnění k mikrofonu),

Ve webové verzi zůstává vše zdarma, bez reklam a bez předplatného.

**Co je zdarma a jak se odemyká:**
- **Zdarma hned (asi 23 % obsahu):** první lekce (5 frází) každého tématu v úrovni Práce a Na cestě, celé téma Nehody a nouze, první lekce Krátkého rozhovoru, 45 nejdůležitějších slovíček a dialogy Příjezd, Doklady a Nehoda.
- **Zbytek se odemyká postupně:** jedna reklama s odměnou odemkne **jednu další lekci** (5 frází) v daném tématu, **15 slovíček** nebo **jeden dialog**. Lekce jdou popořadě, nejde odemknout všechno najednou.
- **PRO (4,99 € měsíčně / 34,99 € ročně):** všechno odemčené hned, bez reklam.
- **Vždy zdarma bez zámku:** překladač, situace (všechny fráze lze ukázat), SOS a fráze k nehodám a policii. Zámky platí jen pro učení, mluvené kartičky a dialogy.

**Reklamy:**
- Bannery (pruhy dole) aplikace nepoužívá. Jen reklama za odměnu (odemčení lekce) a občas celoobrazovková po dokončené aktivitě.
- Celoobrazovková reklama se objeví nejdřív třetí den používání, nejvýš jednou za 4 minuty, a to jen po dokončeném dialogu, briefingu nebo každých 15 procvičených frází.

---

## A. Účty (jednou, zdarma nebo za malý poplatek)

| Služba | K čemu | Co si poznamenat |
|---|---|---|
| **Google Play Console** (play.google.com/console) | zveřejnění aplikace; jednorázový registrační poplatek | – |
| **AdMob** (admob.google.com) | reklamy | ID aplikace `ca-app-pub-…~…`, ID jednotek *Interstitial* (vsunutá) a *Rewarded* (s odměnou); banner nezakládejte |
| **RevenueCat** (revenuecat.com) | předplatné, ověřování plateb | *Google Play public API key* (`goog_…`) |

## B. Počítač (jednou)

1. Nainstalujte **Node.js LTS** (nodejs.org).
2. Nainstalujte **Android Studio** (developer.android.com/studio). Při prvním spuštění nechte doinstalovat Android SDK.

## C. Sestavení aplikace

1. Rozbalte tuto složku, např. do `C:\Dokvox\dokvox-android`.
2. Otevřete `web\config.js` v Poznámkovém bloku a vyplňte:
   - `admob.appId`, `admob.interstitialId` a `admob.rewardedId` (z AdMobu),
   - `revenuecatKey` (z RevenueCatu),

   Nechte `testing: true`, dokud testujete. **Před vydáním přepněte na `false`.**
3. Dvakrát klikněte na **`1_priprava.bat`**. Poprvé to trvá několik minut, protože se stahují knihovny.
4. Dvakrát klikněte na **`2_otevrit_android_studio.bat`**. Počkejte, až Android Studio dole dokončí „Gradle sync“.
5. **Vyzkoušení na telefonu:**
   1. V telefonu zapněte *Možnosti pro vývojáře → Ladění USB*.
   2. Připojte telefon kabelem.
   3. V Android Studiu klikněte na zelené ▶.
6. **Balíček pro Google Play:**
   1. Zvolte *Build → Generate Signed App Bundle or APK → Android App Bundle*.
   2. Vytvořte nový klíč (*Create new…*).
   3. **Soubor s klíčem (.jks) a obě hesla si bezpečně uložte na dvě místa.** Bez nich nejde vydat aktualizaci.
   4. Zvolte variantu *release* a dokončete.
   5. Výsledný soubor najdete v `android\app\release\app-release.aab`.

Když se cokoli pokazí, zkopírujte text chyby a pošlete mi ho.

## D. Google Play Console

1. **Vytvořit aplikaci:** název *Dokvox*, typ *Aplikace*, *Zdarma*.
2. **Testování → Interní testování:** nahrajte `app-release.aab`. Bez nahraného balíčku nejde vytvořit předplatné.
3. **Zpeněžení → Předplatná:** vytvořte předplatné `dokvox_pro` se dvěma základními tarify: *měsíční* za **4,99 €** a *roční* za **34,99 €** (vychází 2,92 € měsíčně, sleva 42 %). Ceny v dalších měnách nechte Google přepočítat. Ke každému tarifu přidejte nabídku *Bezplatná zkušební verze* na **7 dní** pro nové zákazníky.
4. **RevenueCat:**
   1. Přidejte aplikaci Google Play s balíčkem `app.dokvox`.
   2. Nahrajte servisní účet podle jejich návodu (*Google Play service credentials*).
   3. Vytvořte **Entitlement `pro`**.
   4. Vytvořte **Offering `default`** se dvěma balíčky (*Monthly*, *Annual*) navázanými na tarify z kroku 3.
5. **AdMob:** propojte aplikaci s Google Play, až bude zveřejněná.
6. **Obsah aplikace:** vyplňte formuláře.
   - *Zásady ochrany osobních údajů:* `https://VAŠE-DOMÉNA/ochrana-udaju.html`. Nejdřív v tom souboru doplňte žlutá pole.
   - *Reklamy:* Ano.
   - *Přístup k aplikaci:* bez přihlášení.
   - *Cílová skupina:* 18+.
   - *Hodnocení obsahu:* dotazník.
   - *Bezpečnost údajů:* tabulka níže.
7. **Záznam v obchodě:** texty, ikona 512 × 512 (`znacka/dokvox-ikona-512.png` ve webové složce), obrázek 1024 × 500 a snímky obrazovky.
8. **Uzavřený test:** u osobního účtu aspoň **12 testerů po dobu 14 dní v kuse**. Pak můžete požádat o produkci.

## E. Soubor app-ads.txt

AdMob vám dá jeden řádek textu. Uložte ho do souboru `app-ads.txt` ve webové složce (vedle `index.html`) a nahrajte na Netlify. V záznamu Google Play musí být jako web uvedená **stejná doména**.

## F. Nová verze

1. Novou webovou verzi (obsah zipu PWA) nakopírujte do složky `web\`. **Svůj `config.js` si přitom ponechte.**
2. Spusťte **`3_aktualizovat.bat`**.
3. Spusťte **`2_otevrit_android_studio.bat`** a sestavte nový balíček podle kroku C6, **se stejným klíčem**.

Číslo verze se zvyšuje samo.

## G. Bezpečnost údajů – podklad pro formulář v Play Console

| Typ údajů | Sbírá se? | Sdílí se? | Účel | Kdo |
|---|---|---|---|---|
| ID zařízení (reklamní ID) | ano | ano | reklamy, analytika | AdMob |
| Přibližná poloha (z IP) | ano | ano | reklamy | AdMob |
| Interakce s aplikací | ano | ano | reklamy, analytika | AdMob |
| Historie nákupů | ano | ne | funkce aplikace (PRO) | Google Play, RevenueCat |
| Další obsah od uživatele (text zadaný do Překladače, jen když slovo není ve slovníku) | ano | ano | funkce aplikace (překlad) | MyMemory (Translated srl) |
| Fotky (překlad fotky) | ne – text se z fotky čte přímo v telefonu, odesílá se jen přečtený text (viz řádek výše) | – | – | – |
| Zvuk (mikrofon) | ne – rozpoznávání řeči dělá služba systému Android (Google) a aplikace dostane jen text | – | – | – |

Přenos je šifrovaný (HTTPS). O smazání údajů může uživatel požádat e-mailem.

Ověřte prosím aktuální znění formuláře. Konečné prohlášení je vaše odpovědnost.

---

### Co se v tomto prostředí nedalo ověřit
Android SDK ani stahování knihoven tu nejsou dostupné, takže jsem aplikaci nemohl skutečně sestavit. Logiku reklam, předplatného a připomínek jsem otestoval ve webovém prohlížeči se simulací těchto služeb. Úpravy Android projektu jsem otestoval na vzorovém projektu. Při prvním sestavení mohou být potřeba drobné opravy podle verzí knihoven. V tom případě mi pošlete text chyby.
