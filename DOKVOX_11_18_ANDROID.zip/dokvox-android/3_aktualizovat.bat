@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === Dokvox: aktualizace po zmene webu nebo config.js ===
node priprava.js www || goto chyba
call npx cap sync android || goto chyba
node priprava.js android || goto chyba
echo HOTOVO.
pause
exit /b 0
:chyba
echo CHYBA - zkopirujte text vyse a poslete ho.
pause
exit /b 1
