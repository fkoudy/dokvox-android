@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === Dokvox: priprava Android projektu ===
call npm install --legacy-peer-deps || goto chyba
node priprava.js www || goto chyba
if not exist android ( call npx cap add android || goto chyba )
call npx cap sync android || goto chyba
node priprava.js android || goto chyba
echo.
echo HOTOVO. Pokracujte souborem 2_otevrit_android_studio.bat
pause
exit /b 0
:chyba
echo.
echo CHYBA - zkopirujte text vyse a poslete ho.
pause
exit /b 1
