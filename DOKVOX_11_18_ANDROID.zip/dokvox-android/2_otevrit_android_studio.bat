@echo off
cd /d "%~dp0"
call npx cap open android
