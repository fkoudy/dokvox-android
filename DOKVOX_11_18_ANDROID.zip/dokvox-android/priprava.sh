#!/bin/sh
# Mac / Linux: totéž co 1_priprava.bat
set -e
cd "$(dirname "$0")"
npm install --legacy-peer-deps
node priprava.js www
[ -d android ] || npx cap add android
npx cap sync android
node priprava.js android
echo "HOTOVO. Dál: npx cap open android"
