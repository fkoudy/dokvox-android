/* DOKVOX – nastavení. Upravte v Poznámkovém bloku, uložte a nahrajte znovu (web i Android).
   Prázdná hodnota = funkce je vypnutá. NIKDY sem nevkládejte tajné klíče (secret / service_role). */
window.TL_CONFIG = {
  /* Konvoj, žebříček a firemní licence – Supabase → Project Settings → API Keys / Data API */
  supabaseUrl: 'https://ukdxpwjfdzaiumqxpidj.supabase.co',            // např. 'https://abcdefgh.supabase.co'
  supabaseKey: 'sb_publishable_9lIyEQApXNaBVsbT9Gk5qA_GgL6l0jL',            // Publishable key 'sb_publishable_…'

  /* Web je ukázka: zdarma asi pětina lekcí, zbytek odkazuje na aplikaci. false = web bude celý zdarma (např. pro testování) */
  webLocked: true,
  playUrl: 'https://play.google.com/store/apps/details?id=app.dokvox',   // odkaz na aplikaci v Google Play

  /* Jen pro aplikaci z Google Play: předplatné PRO – RevenueCat → Project → API keys → Google Play public key */
  revenuecatKey: '',          // např. 'goog_AbCdEf…'
  entitlement: 'pro',         // název „Entitlement“ v RevenueCat

  /* Jen pro aplikaci z Google Play: reklamy – AdMob → Aplikace / Reklamní jednotky */
  admob: {
    appId: '',                // ID aplikace, tvar 'ca-app-pub-1234567890123456~1234567890'
    bannerId: '',             // ID jednotky „Banner“, tvar 'ca-app-pub-…/…'
    interstitialId: '',       // ID jednotky „Interstitial“ (celoobrazovková)
    rewardedId: '',           // ID jednotky „Rewarded“ (s odměnou) – odemyká lekce za reklamu
    testing: true             // true = zkušební reklamy. Před vydáním přepněte na false!
  }
};
