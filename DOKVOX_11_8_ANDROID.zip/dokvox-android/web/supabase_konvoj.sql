-- DOKVOX 10.7 · Konvoj, firemní žebříček a firemní licence PRO
-- Spusťte JEDNOU v Supabase: projekt → SQL Editor → New query → vložit → Run.
-- Tabulky nejsou přímo čitelné ani zapisovatelné (RLS bez pravidel).
-- Aplikace smí jen volat funkce níže; každý člen se prokazuje tajným klíčem svého telefonu.

create table if not exists public.tl_convoys (
  code       text primary key,
  name       text not null check (char_length(name) between 1 and 40),
  kind       text not null default 'crew' check (kind in ('crew','company')),
  created_at timestamptz not null default now()
);

create table if not exists public.tl_members (
  id         uuid primary key default gen_random_uuid(),
  convoy     text not null references public.tl_convoys(code) on delete cascade,
  nick       text not null check (char_length(nick) between 1 and 24),
  secret     text not null,                -- md5 tajného klíče z telefonu
  lang       text not null default '',
  week       text not null default '',
  week_xp    int  not null default 0,
  total_xp   int  not null default 0,
  streak     int  not null default 0,
  updated_at timestamptz not null default now()
);
create index if not exists tl_members_convoy_idx on public.tl_members(convoy);

alter table public.tl_convoys enable row level security;
alter table public.tl_members enable row level security;
revoke all on public.tl_convoys, public.tl_members from anon, authenticated;

-- vytvořit konvoj (autor se rovnou stává členem)
create or replace function public.tl_create(p_name text, p_kind text, p_nick text, p_secret text, p_lang text)
returns json language plpgsql security definer set search_path = public as $$
declare v_code text; v_id uuid; v_try int := 0;
begin
  if char_length(coalesce(p_secret,'')) < 16 then raise exception 'bad_secret'; end if;
  if char_length(trim(coalesce(p_nick,''))) = 0 or char_length(trim(coalesce(p_name,''))) = 0 then raise exception 'bad_name'; end if;
  loop
    v_code := '';
    for j in 1..6 loop
      v_code := v_code || substr('ABCDEFGHJKMNPQRSTUVWXYZ23456789', 1 + floor(random()*31)::int, 1);
    end loop;
    exit when not exists (select 1 from tl_convoys where code = v_code);
    v_try := v_try + 1;
    if v_try > 30 then raise exception 'no_code'; end if;
  end loop;
  insert into tl_convoys(code, name, kind)
    values (v_code, left(trim(p_name),40), case when p_kind = 'company' then 'company' else 'crew' end);
  insert into tl_members(convoy, nick, secret, lang)
    values (v_code, left(trim(p_nick),24), md5(p_secret), left(coalesce(p_lang,''),5))
    returning id into v_id;
  return json_build_object('code', v_code, 'id', v_id, 'name', left(trim(p_name),40),
                           'kind', case when p_kind = 'company' then 'company' else 'crew' end);
end $$;

-- připojit se kódem
create or replace function public.tl_join(p_code text, p_nick text, p_secret text, p_lang text)
returns json language plpgsql security definer set search_path = public as $$
declare v_c tl_convoys; v_id uuid;
begin
  if char_length(coalesce(p_secret,'')) < 16 then raise exception 'bad_secret'; end if;
  if char_length(trim(coalesce(p_nick,''))) = 0 then raise exception 'bad_name'; end if;
  select * into v_c from tl_convoys where code = upper(trim(p_code));
  if not found then raise exception 'not_found'; end if;
  select id into v_id from tl_members where convoy = v_c.code and secret = md5(p_secret);
  if v_id is null then
    if (select count(*) from tl_members where convoy = v_c.code) >= 300 then raise exception 'full'; end if;
    insert into tl_members(convoy, nick, secret, lang)
      values (v_c.code, left(trim(p_nick),24), md5(p_secret), left(coalesce(p_lang,''),5))
      returning id into v_id;
  end if;
  return json_build_object('code', v_c.code, 'id', v_id, 'name', v_c.name, 'kind', v_c.kind);
end $$;

-- poslat svůj týdenní stav
create or replace function public.tl_push(p_id uuid, p_secret text, p_week text, p_week_xp int,
                                          p_total_xp int, p_streak int, p_nick text, p_lang text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update tl_members set
    week     = left(coalesce(p_week,''),10),
    week_xp  = greatest(0, least(coalesce(p_week_xp,0), 20000)),
    total_xp = greatest(0, least(coalesce(p_total_xp,0), 2000000)),
    streak   = greatest(0, least(coalesce(p_streak,0), 3650)),
    nick     = coalesce(nullif(left(trim(coalesce(p_nick,'')),24),''), nick),
    lang     = left(coalesce(p_lang,''),5),
    updated_at = now()
  where id = p_id and secret = md5(coalesce(p_secret,''));
  if not found then raise exception 'denied'; end if;
end $$;

-- žebříček konvoje
create or replace function public.tl_board(p_code text, p_week text)
returns json language sql security definer set search_path = public as $$
  select json_build_object(
    'code', c.code, 'name', c.name, 'kind', c.kind,
    'members', coalesce((
      select json_agg(json_build_object(
               'id', m.id, 'nick', m.nick, 'lang', m.lang, 'streak', m.streak, 'total', m.total_xp,
               'xp', case when m.week = p_week then m.week_xp else 0 end,
               'active', m.updated_at > now() - interval '8 days')
             order by (case when m.week = p_week then m.week_xp else 0 end) desc, m.total_xp desc)
      from tl_members m where m.convoy = c.code), '[]'::json))
  from tl_convoys c where c.code = upper(trim(p_code));
$$;

-- opustit konvoj (prázdný konvoj zmizí)
create or replace function public.tl_leave(p_id uuid, p_secret text)
returns void language plpgsql security definer set search_path = public as $$
declare v_code text;
begin
  delete from tl_members where id = p_id and secret = md5(coalesce(p_secret,'')) returning convoy into v_code;
  if v_code is not null and not exists (select 1 from tl_members where convoy = v_code) then
    delete from tl_convoys where code = v_code;
  end if;
end $$;

revoke execute on function public.tl_create(text,text,text,text,text), public.tl_join(text,text,text,text),
  public.tl_push(uuid,text,text,int,int,int,text,text), public.tl_board(text,text), public.tl_leave(uuid,text) from public;
grant execute on function public.tl_create(text,text,text,text,text), public.tl_join(text,text,text,text),
  public.tl_push(uuid,text,text,int,int,int,text,text), public.tl_board(text,text), public.tl_leave(uuid,text) to anon, authenticated;

-- ---------- Firemní licence PRO (kód pro řidiče jedné firmy) ----------
-- Novou licenci vytvoříte v Supabase → SQL Editor příkazem (vrátí náhodný 12místný kód):
--   select public.tl_new_license('Spedtrans s.r.o.', 25, '2027-12-31');
-- Kód nevymýšlejte ručně: krátký nebo čitelný kód (např. název firmy) by šel uhodnout.
create table if not exists public.tl_licenses (
  code        text primary key check (code = upper(code) and char_length(code) between 10 and 20),
  company     text not null,
  seats       int  not null default 10 check (seats > 0),
  valid_until date not null,
  created_at  timestamptz not null default now()
);
create table if not exists public.tl_license_devices (
  code    text not null references public.tl_licenses(code) on delete cascade,
  secret  text not null,                 -- md5 tajného klíče telefonu
  used_at timestamptz not null default now(),
  primary key (code, secret)
);
alter table public.tl_licenses enable row level security;
alter table public.tl_license_devices enable row level security;
revoke all on public.tl_licenses, public.tl_license_devices from anon, authenticated;

-- uplatnit kód (stejný telefon může kód použít opakovaně, nový telefon zabere jedno místo)
create or replace function public.tl_redeem(p_code text, p_secret text)
returns json language plpgsql security definer set search_path = public as $$
declare v_l tl_licenses;
begin
  if char_length(coalesce(p_secret,'')) < 16 then raise exception 'bad_secret'; end if;
  select * into v_l from tl_licenses where code = upper(trim(p_code));
  if not found or v_l.valid_until < current_date then raise exception 'invalid'; end if;
  if not exists (select 1 from tl_license_devices where code = v_l.code and secret = md5(p_secret)) then
    if (select count(*) from tl_license_devices where code = v_l.code) >= v_l.seats then raise exception 'full'; end if;
    insert into tl_license_devices(code, secret) values (v_l.code, md5(p_secret));
  end if;
  return json_build_object('company', v_l.company, 'valid_until', v_l.valid_until);
end $$;
revoke execute on function public.tl_redeem(text,text) from public;
grant execute on function public.tl_redeem(text,text) to anon, authenticated;

-- vytvoření licence s náhodným kódem (jen pro správce v SQL Editoru, aplikace ji volat nemůže)
create or replace function public.tl_new_license(p_company text, p_seats int, p_valid_until date)
returns text language plpgsql security definer set search_path = public as $$
declare v_code text; v_abc text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; i int;
begin
  loop
    v_code := '';
    for i in 1..12 loop v_code := v_code || substr(v_abc, 1 + floor(random()*length(v_abc))::int, 1); end loop;
    exit when not exists (select 1 from tl_licenses where code = v_code);
  end loop;
  insert into tl_licenses(code, company, seats, valid_until) values (v_code, p_company, p_seats, p_valid_until);
  return v_code;
end $$;
revoke execute on function public.tl_new_license(text,int,date) from public, anon, authenticated;
