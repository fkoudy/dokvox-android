# DOKVOX 11.3 – návod k nasazení

## Co je v balíčku
| Soubor | K čemu slouží |
|---|---|
| `index.html` | celá aplikace (obsah, 15 jazyků, ilustrace, fonty) |
| `manifest.webmanifest` | údaje pro instalaci na plochu telefonu |
| `sw.js` | service worker – aplikace funguje offline |
| `icon-192.png`, `icon-512.png`, `icon-maskable-512.png` | ikony aplikace |
| `config.js` | nastavení: server pro Konvoj a firemní licence, klíče pro reklamy a předplatné (prázdné = vypnuto) |
| `ochrana-udaju.html` | zásady ochrany osobních údajů – doplňte žlutá pole, adresu stránky zadáte do Google Play |
| složka `znacka/` | logo a ikona Dokvox (SVG pro tisk a web, PNG pro Google Play) – na web se nahrávat nemusí |
| `supabase_konvoj.sql` | databáze pro Konvoj – spustí se jednou v Supabase (nenahrává se na web) |
| složka `audio/` (až bude) | nahrávky rodilých mluvčích |

## Web jako ukázka (od verze 11.3)

Na webu je zdarma stejná část jako v aplikaci (asi 23 % frází, 45 slovíček, dialogy Příjezd, Doklady a Nehoda). Fráze pro nehody, policii a SOS jsou vždy otevřené. U zamčených lekcí web ukáže tlačítko **Odemknout v aplikaci** (odkaz na Google Play) a **Mám kód od firmy** – firemní licence odemkne vše i na webu.

V `config.js`:
- `playUrl` – odkaz na aplikaci v Google Play (po zveřejnění zkontrolujte, že sedí),
- `webLocked: false` – web bude celý zdarma (hodí se pro vlastní testování).

## 1. Zveřejnění na internetu (zdarma, cca 5 minut)
Aplikace musí běžet na adrese **https://**, jinak ji nepůjde nainstalovat ani spustit offline.

**Nejjednodušší cesta – Netlify Drop:**
1. Otevři `app.netlify.com/drop`.
2. Přetáhni do okna celou složku s těmito soubory.
3. Dostaneš odkaz typu `https://neco.netlify.app` – ten pošli testerům.

Alternativy: GitHub Pages, Cloudflare Pages (obě zdarma).

> **Jen z mobilu:** otevřete v Chrome stránku app.netlify.com/drop, klepněte do pole pro nahrání a vyberte celý soubor `DOKVOX_…_PWA.zip`. Netlify ho rozbalí a dá vám adresu https://….netlify.app. Mikrofon, instalace na plochu a práce bez internetu fungují **jen přes tuto https adresu** – ne když index.html otevřete přímo ze souborů v telefonu.

## 2. Instalace na telefon (Android)
1. Otevři odkaz v Chrome.
2. Menu ⋮ → **Přidat na plochu / Nainstalovat aplikaci**.
3. Po prvním spuštění funguje i bez internetu.

## 3. Cesta do Google Play
Pro reklamy (AdMob) a předplatné přes Google Play je potřeba z webové aplikace udělat nativní balíček.

| Varianta | Kdy použít | Reklamy AdMob | Předplatné Google Play |
|---|---|---|---|
| **PWABuilder (TWA)** – pwabuilder.com, vloží se URL a vygeneruje se balíček pro Google Play | rychlý start bez reklam | ne | jen přes Play Billing v TWA (složitější) |
| **Capacitor** (Ionic) – web se zabalí do nativní aplikace | když chceš reklamy a předplatné | ano (plugin `@capacitor-community/admob`) | ano (plugin pro Google Play Billing) |

**Doporučení:** testovat jako webovou aplikaci (krok 1–2), do Google Play jít přes **Capacitor** – vše je připravené v balíčku `DOKVOX_11_3_ANDROID.zip`, podrobný postup je v jeho souboru `NAVOD_GOOGLE_PLAY.md`.

### Důležitá pravidla Google Play
- **Nový osobní vývojářský účet** musí před zveřejněním provést **uzavřený test: aspoň 12 testerů po dobu 14 dní v kuse**.
- **Firemní účet** (s číslem D-U-N-S) tuto povinnost nemá, ale získání čísla D-U-N-S může trvat až měsíc.
- Je potřeba **zásady ochrany osobních údajů** (webová stránka) – zvlášť při reklamách.
- Reklamy v EU vyžadují **souhlas uživatele (GDPR)** – AdMob na to má hotové okno (UMP).

## 4. QR kód pro sklady
1. Aplikaci nejdřív zveřejněte (krok 1) – QR kód musí obsahovat její **https adresu**.
2. V aplikaci: **Profil → Užitečné nástroje → Pro sklady: QR kód areálu**.
3. Vyplňte název, adresu, telefon na vrátnici, provozní dobu, rychlost v areálu a zaškrtněte pravidla.
4. Zadejte adresu aplikace a klepněte na **Vytvořit QR kód** → **Vytisknout plakát**.
5. Řidič QR kód naskenuje fotoaparátem telefonu (nebo tlačítkem „Naskenovat QR kód areálu“ v aplikaci) a pravidla uvidí ve svém jazyce.

QR kód obsahuje jen čísla pravidel a údaje areálu – žádný server ani registrace nejsou potřeba. Pravidla se nesmí přečíslovat: nová se přidávají jen na konec seznamu (`depot.js`).

## 5. Nahrávky rodilých mluvčích (místo robotického hlasu)
Aplikace přehraje nahrávku rodilého mluvčího, pokud pro frázi existuje. Jinak použije hlas telefonu.

**Jak nahrávky získat:**
1. Najděte rodilého mluvčího (např. německého skladníka nebo kolegu řidiče).
2. Pošlete mu odkaz `https://vase-adresa/#studio=de` (místo `de` dejte kód jazyka) – nebo v aplikaci **Profil → Užitečné nástroje → Nahrávací studio → Poslat odkaz rodilému mluvčímu**.
3. Mluvčí v telefonu čte fráze nahlas (jedno klepnutí = start, druhé = stop), u každé potvrdí, že překlad sedí, nebo ho opraví.
4. Na konci klepne na **Exportovat nahrávky (ZIP)** a soubor vám pošle (WhatsApp, e-mail).

**Jak nahrávky přidat do aplikace:**
1. Rozbalte ZIP. Je v něm složka `audio/de/…` a soubor `opravy_de.txt`.
2. Složku `audio` dejte vedle `index.html` a celou složku znovu nahrajte na Netlify (krok 1).
3. Opravy překladů z `audio/de/index.json` aplikace převezme sama. Soubor `opravy_de.txt` je pro vás ke kontrole.

Tipy: nahrávat v tichu, telefon 20 cm od úst. Jeden jazyk = jeden mluvčí (druhý export stejného jazyka by soubor `index.json` přepsal – pak mi oba ZIPy pošlete a spojím je). Nahrávky jsou ve formátu WebM, který přehraje každý Android.

## 6. Konvoj – žebříček s kolegy a firmami
Řidiči si založí konvoj (parta nebo firma), pozvou kolegy kódem nebo odkazem a společně „ujíždějí kilometry“ (1 XP = 1 km). Žebříček se nuluje každé pondělí. Potřebuje malý server – stačí bezplatný účet **Supabase**:

1. Na **supabase.com** si založte účet a **New project** (region: *Frankfurt / EU Central* – kvůli GDPR).
2. V projektu otevřete **SQL Editor → New query**, vložte celý obsah souboru `supabase_konvoj.sql` a klepněte **Run**. (Dá se spustit i opakovaně, nic nesmaže.)
3. Otevřete **Project Settings → API Keys** (a **Data API**) a zkopírujte **Project URL** a **Publishable key**.
4. Obě hodnoty vložte do `config.js` (otevřete v Poznámkovém bloku) a složku znovu nahrajte na Netlify.
5. Hotovo – v aplikaci se objeví **Kariéra → Konvoj**.

Bezpečnost: tabulky nejdou číst ani měnit přímo, aplikace smí jen volat 5 připravených funkcí. Každý telefon má vlastní tajný klíč, takže nikdo nemůže měnit body jiných. Na server jde jen přezdívka, týdenní XP, celkové XP, série a učený jazyk – uveďte to v zásadách ochrany osobních údajů. Bezplatný projekt Supabase se podle jejich podmínek uspí po delší nečinnosti (zhruba týden bez provozu) – v Supabase ho pak stačí jedním klepnutím probudit.

## 7. Název Dokvox
- Před zveřejněním kupte doménu (např. dokvox.com / .app / .eu) a zvažte zápis ochranné známky (EUIPO nebo ÚPV, třídy 9 a 41).
- Pokrok testerů z dřívější verze TRUCKLINGO zůstane zachovaný – data v telefonu se nepřejmenovávají.

## 8. Před ostrým spuštěním
- Překlady jsou připravené s pomocí AI. **Před spuštěním je musí zkontrolovat rodilí mluvčí**, hlavně fráze pro nehody, ADR a policii.
- Pokrok se ukládá v telefonu. Na server (pokud zapnete Konvoj) jde jen přezdívka a body.

## Úprava obsahu
Fráze jsou v souboru zdrojů `content.js` (ve vývojové verzi) ve tvaru:
`'Česky|English|Deutsch|Polski|Français|Italiano|Español|Nederlands|Română|Українська|Русский|Türkçe|Oʻzbekcha|हिन्दी|العربية'`
Nový jazyk = přidat sloupec do všech frází a texty rozhraní do `i18n.js`.
