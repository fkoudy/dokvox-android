/* Dokvox – příprava Android projektu.
   node priprava.js www      → zkopíruje web/ do www/
   node priprava.js android  → doplní do android/ ikony, AdMob ID, oprávnění a číslo verze */
const fs = require('fs'), path = require('path'), vm = require('vm');
const DIR = __dirname, WEB = path.join(DIR, 'web'), WWW = path.join(DIR, 'www'), AND = path.join(DIR, 'android');
const SKIP = new Set(['sw.js', 'NAVOD.md', 'supabase_konvoj.sql', 'znacka', '_headers']);
const step = process.argv[2];
function copyDir(a, b) {
  fs.mkdirSync(b, { recursive: true });
  for (const f of fs.readdirSync(a)) {
    if (SKIP.has(f)) continue;
    const s = path.join(a, f), d = path.join(b, f);
    fs.statSync(s).isDirectory() ? copyDir(s, d) : fs.copyFileSync(s, d);
  }
}
function readConfig() {
  const ctx = { window: {} };
  try { vm.runInNewContext(fs.readFileSync(path.join(WEB, 'config.js'), 'utf8'), ctx); } catch (e) { console.log('! config.js nejde přečíst:', e.message); }
  return ctx.window.TL_CONFIG || {};
}
function write(rel, text) { const f = path.join(AND, 'app', 'src', 'main', 'res', rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, text); }

if (step === 'www') {
  if (!fs.existsSync(path.join(WEB, 'index.html'))) { console.error('Chybí složka web/ s index.html'); process.exit(1); }
  fs.rmSync(WWW, { recursive: true, force: true });
  copyDir(WEB, WWW);
  const cfg = readConfig();
  if (cfg.admob && cfg.admob.testing) console.log('! Reklamy jsou v režimu TEST (config.js → admob.testing). Před vydáním přepněte na false.');
  console.log('✓ Web zkopírován do www/');
} else if (step === 'android') {
  if (!fs.existsSync(AND)) { console.error('Složka android/ ještě neexistuje – spusťte nejdřív 1_priprava.'); process.exit(1); }
  const cfg = readConfig(), ad = cfg.admob || {};
  const TEST_APP = 'ca-app-pub-3940256099942544~3347511713';
  const appId = ad.appId || TEST_APP;
  if (!ad.appId) console.log('! V config.js chybí admob.appId – použito zkušební ID Googlu.');
  // AndroidManifest: AdMob APPLICATION_ID + oznámení
  const mf = path.join(AND, 'app', 'src', 'main', 'AndroidManifest.xml');
  let x = fs.readFileSync(mf, 'utf8');
  if (x.includes('gms.ads.APPLICATION_ID')) x = x.replace(/(gms\.ads\.APPLICATION_ID"\s+android:value=")[^"]*/, '$1' + appId);
  else x = x.replace(/<application([^>]*)>/, m => m + `\n        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="${appId}"/>`);
  if (!x.includes('android.permission.POST_NOTIFICATIONS')) x = x.replace('</manifest>', '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n</manifest>');
  if (!x.includes('android.permission.CAMERA')) x = x.replace('</manifest>', '    <uses-permission android:name="android.permission.CAMERA" />\n</manifest>');
  if (!x.includes('android.permission.RECORD_AUDIO')) x = x.replace('</manifest>', '    <uses-permission android:name="android.permission.RECORD_AUDIO" />\n</manifest>');
  if (!x.includes('com.google.android.gms.permission.AD_ID')) x = x.replace('</manifest>', '    <uses-permission android:name="com.google.android.gms.permission.AD_ID" />\n</manifest>');
  fs.writeFileSync(mf, x);
  // Ikona aplikace (adaptivní, vektorová) a ikona oznámení
  const BUBBLE = 'M24,10h72a14,14 0,0 1,14 14v52a14,14 0,0 1,-14 14H50L26,110l4,-20h-6A14,14 0,0 1,10 76V24A14,14 0,0 1,24 10z';
  write('drawable/dokvox_fg.xml', `<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="120" android:viewportHeight="120">
  <group android:scaleX="0.58" android:scaleY="0.58" android:pivotX="60" android:pivotY="62">
    <path android:fillColor="#FFFFFF" android:pathData="${BUBBLE}"/>
    <path android:strokeColor="#0A5A3B" android:strokeWidth="5" android:strokeLineCap="round" android:pathData="M60,22V78"/>
    <path android:strokeColor="#0A5A3B" android:strokeAlpha="0.5" android:strokeWidth="3.5" android:strokeLineCap="round" android:pathData="M38,26V74M82,26V74"/>
    <path android:fillColor="#0A5A3B" android:pathData="M35.5,46h5a2.5,2.5 0,0 1,0 5h-5a2.5,2.5 0,0 1,0 -5zM79.5,46h5a2.5,2.5 0,0 1,0 5h-5a2.5,2.5 0,0 1,0 -5z"/>
    <path android:fillColor="#F5A623" android:strokeColor="#0B5A39" android:strokeWidth="4" android:pathData="M104,3a11,11 0,1 1,0 22a11,11 0,1 1,0 -22z"/>
  </group>
</vector>
`);
  write('values/dokvox_colors.xml', `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n  <color name="dokvox_bg">#0B5A39</color>\n</resources>\n`);
  const adaptive = `<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n  <background android:drawable="@color/dokvox_bg"/>\n  <foreground android:drawable="@drawable/dokvox_fg"/>\n  <monochrome android:drawable="@drawable/dokvox_fg"/>\n</adaptive-icon>\n`;
  write('mipmap-anydpi-v26/ic_launcher.xml', adaptive);
  write('mipmap-anydpi-v26/ic_launcher_round.xml', adaptive);
  write('drawable/ic_stat_dokvox.xml', `<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="120" android:viewportHeight="120">
  <path android:fillColor="#FFFFFF" android:pathData="${BUBBLE}"/>
</vector>
`);
  // Číslo verze: každé sestavení má vyšší versionCode (Google Play to vyžaduje)
  const gradle = path.join(AND, 'app', 'build.gradle');
  if (fs.existsSync(gradle)) {
    const ver = require('./package.json').version, code = Math.floor(Date.now() / 60000) - 29000000;
    let g = fs.readFileSync(gradle, 'utf8');
    g = g.replace(/versionCode\s+\d+/, 'versionCode ' + code).replace(/versionName\s+"[^"]*"/, `versionName "${ver}"`);
    fs.writeFileSync(gradle, g);
    console.log(`✓ Verze ${ver} (versionCode ${code})`);
  }
  console.log('✓ Android projekt doplněn (ikona, AdMob, oznámení)');
} else {
  console.log('Použití: node priprava.js www | android');
}
